# Python-RPG
a CLI-only function based RPG with Medieval settings, using a well known game lore.

This was my frist solo project, and as you may see, it works, but not perfectly xD

A friend of mine told me to make it class based, but I didn't rewrite it. Instead of it, I built a REST API.
